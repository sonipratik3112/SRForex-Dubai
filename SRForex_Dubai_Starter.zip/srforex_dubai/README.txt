SRFOREX DUBAI — STARTER WEBSITE

Files:
- index.html: responsive single-page website starter with sample market data and a local-only virtual practice interaction.

IMPORTANT LIMITATIONS
- This is a front-end prototype, not a live forex platform or brokerage.
- Market prices and calendar entries are illustrative sample data, not live data.
- Demo practice is a simple browser-side educational interaction only. It is not a realistic trading engine and does not connect to a broker.
- No login, registration, customer database, payments, deposits, withdrawals, or real order execution are implemented.
- Do not advertise or operate regulated financial services without obtaining jurisdiction-specific legal advice and required authorisations.

PUBLISHING ON GITHUB PAGES
1. Sign in to GitHub and create a new public repository named srforex-dubai.
2. Upload index.html (and optionally this README.txt) to the repository root.
3. Open repository Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select branch main and folder /(root), then Save.
6. Wait for the Pages URL to appear in Settings > Pages.
7. Test the website on desktop and mobile before sharing it.

BEFORE A PUBLIC BUSINESS LAUNCH
- Replace all sample market prices and sample calendar entries with data from a properly licensed provider.
- Add a secure backend before implementing accounts or storing user data.
- Arrange privacy policy, terms, risk disclosures, cookie notice (where applicable), and security review.
- Obtain written legal advice on the exact services and countries targeted, especially UAE/Dubai and India.
- Do not accept client funds or provide brokerage, investment advice, signals, copy trading or referrals unless properly authorised.
